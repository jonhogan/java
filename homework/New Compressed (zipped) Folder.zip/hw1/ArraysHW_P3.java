/**
*   Author      Jonathan Hogan
*   Class       Dr.Das - CMPS 4143 Contemporary Programming Languages
*   Due         09/15/21                                                   
*   
*    Program for Question 3: You are given a string S. 
*       Find 5 high frequency words using several array operations.
*       
*
*/

import java.util.*;

public class ArraysHW_P3 
{
     public static void main(String[] args)
    {
      String S = "Before trying to do any of the steps below, you should read the article through at least once for basic understanding. " +
      "Then go back and review, following these steps. He ran his machine up to the stone porch and ascending the steps rang the door bell. " +
      "They directed their steps toward the sea, which was lit up by the rising moon. She breathed a sigh of relief, and her light steps " +
      "fell gradually into the measure of his. This was fully four feet under water and the lower story of the place was two steps lower down.";

      System.out.println("Given String: " + S + "\n\n\n");

      //Split words for counting
      String[] words = S.split("\s");
      
      String[] S_Words = new String[words.length]; //Store the words from the string
      int[] wordCount = new int[words.length];     //Store the count of the words
      
      boolean seenBefore = false;                  //Haven't seen the word before, first run so it's false
      int counter = 0;                             //Counter variable

      for (int i = 0; i < words.length; i++)
      {
        for (int j = 0; j < wordCount.length; j++)
        {
            if(words[i].replaceAll("[;,.]","").equalsIgnoreCase(S_Words[j]))
            {
                wordCount[j]++;
                seenBefore = true;
            }
        }

        if (!seenBefore)// Start counting if seen
        {
            S_Words[counter] = S_Words[i].replaceAll("[.,;]", "");
            wordCount[counter] = 1;
            counter += 1;
        }
      }

      for (int i = 0; i < counter; i++)
      {
        for (int j = 0; j < counter - i - 1; j++) 
        {
            if (wordCount[j] < wordCount[j + 1]) 
            {
                int temp = wordCount[j];
                wordCount[j] = wordCount[j + 1];
                wordCount[j + 1] = temp;
                       
                String TempString = S_Words[j];
                S_Words[j] = S_Words[j + 1];
                S_Words[j + 1] = TempString;
            }
        }
      }

        System.out.println("Te top 5 most common words: ");

        for (int i = 0; i < 5; i++)
        {
                 //loop through for loop print out the most frequet that is store in the array
                System.out.println(S_Words[i] + " Appears" + wordCount[i] + " Times.");

        }
      
    }
}
